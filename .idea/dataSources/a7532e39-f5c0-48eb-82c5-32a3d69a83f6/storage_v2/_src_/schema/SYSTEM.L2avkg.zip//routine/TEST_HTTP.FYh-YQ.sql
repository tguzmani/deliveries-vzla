create PROCEDURE test_http (
    in_origin_lat NUMBER,
    in_origin_long NUMBER,
    in_destination_lat NUMBER,
    in_destination_long NUMBER
)
IS
    req utl_http.req;
    res utl_http.resp;
    -- end_point VARCHAR(4000) := 'http://localhost:8000/?data=';

    route VARCHAR2(4000) := 'localhost:8000/?';
    query_origins VARCHAR2(4000) := 
        'originLat=' || in_origin_lat || '&originLong=' || in_origin_long;
    query_destination VARCHAR2(4000) := 
        '&destinationLat=' || in_destination_lat || '&destinationLong=' || in_destination_long;

    url VARCHAR(4000) := route || query_origins || query_destination;
    name VARCHAR2(4000);
    buffer VARCHAR2(4000);
BEGIN
    req := utl_http.begin_request(url, 'GET',' HTTP/1.1');
    -- utl_http.set_header(req, 'user-agent', 'mozilla/4.0'); 
    utl_http.set_header(req, 'content-type', 'application/json'); 
    -- utl_http.set_header(req, 'Content-Length', length(content));

    -- utl_http.write_text(req, content);
    res := utl_http.get_response(req);

    DELETE FROM json_http_helper;

    BEGIN
      LOOP
        utl_http.read_line(res, buffer);
        dbms_output.put_line(url);
        dbms_output.put_line(buffer);
        INSERT INTO json_http_helper VALUES (default, default, buffer);
      END LOOP;
      utl_http.end_response(res);
    EXCEPTION
      WHEN utl_http.end_of_body 
      THEN
        utl_http.end_response(res);
    END;
END;
/

