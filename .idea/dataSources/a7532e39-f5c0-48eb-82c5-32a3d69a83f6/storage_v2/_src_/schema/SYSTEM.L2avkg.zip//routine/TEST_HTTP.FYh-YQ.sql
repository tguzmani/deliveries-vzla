create PROCEDURE test_http (
    in_query VARCHAR
)
IS
    req utl_http.req;
    res utl_http.resp;
    url VARCHAR2(4000) := 'http://localhost:8000/?data=' || in_query;
    name VARCHAR2(4000);
    buffer VARCHAR2(4000);
BEGIN
    req := utl_http.begin_request(url, 'GET',' HTTP/1.1');
    -- utl_http.set_header(req, 'user-agent', 'mozilla/4.0'); 
    utl_http.set_header(req, 'content-type', 'application/json'); 
    -- utl_http.set_header(req, 'Content-Length', length(content));

    -- utl_http.write_text(req, content);
    res := utl_http.get_response(req);

    DELETE FROM json_http_helper;

    BEGIN
      LOOP
        utl_http.read_line(res, buffer);
        dbms_output.put_line(buffer);
        INSERT INTO json_http_helper VALUES (default, default, buffer);
      END LOOP;
      utl_http.end_response(res);
    EXCEPTION
      WHEN utl_http.end_of_body 
      THEN
        utl_http.end_response(res);
    END;
END;
/

